
print("programming programming")


val = 10
print(val)
print("Output:", val)

print(10,20,30,40,65)



aname = 'python programming'
bname = "spark programming"
cname = """machine learning"""

print(aname)
print(bname)
print(cname)
print(aname,bname,cname)
print("I love",aname)
