


aset = {10,20,10,10,10,30,40}

print("Elements are :", aset)