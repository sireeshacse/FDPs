atup = (34,3,43,43)
btup = ("scala","hadoop","oracle")
ctup = (40,"java",45.3,"oracle")


atup[0] = 10000
print(atup)


print("elemennts are :", btup)