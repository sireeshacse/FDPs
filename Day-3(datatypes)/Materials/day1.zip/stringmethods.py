

name = "python programming"

#name[0] = "z"
print(name)


print(name.upper())
print(name.lower())
print(name.islower())
print(name.isupper())
print(name.split(" "))
print(name.capitalize())
print(name.center(50))
print(name.center(50,"*"))

query = "I love {} and {}"

print(query.format("python","hadoop"))
print(query.format(1,2))


val = None
print(val)
