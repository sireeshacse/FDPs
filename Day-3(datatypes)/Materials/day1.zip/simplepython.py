
print("python programming for machine learning")