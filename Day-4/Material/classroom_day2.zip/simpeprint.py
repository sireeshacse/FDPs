
print(10,20,sep=":")


print(10,end="\n\n\n\n\n")
print(20)


for val in range(1,11):
    print(val,end=" ")
    
    
name = "   python   "
print(len(name))

name = name.strip()
print(len(name))