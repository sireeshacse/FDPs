
# for loop with range

for val in range(1,11,2):
    print(val)
for val in range(2,11,2):
    print(val)
    
# for loop using string
string = "python"
for char in string:
    print(char)
    
# for loop with list
alist = [10,20,30,40]
for value in alist:
    print(value)

# for loop with dictionary
adict = {"chap1":10 ,"chap2":20 ,"chap3":30}
for key,value in adict.items():
    print(key,value)
# displaying ONLY keys    
for key in adict.keys():
    print(key)
# displaying ONLY vlaues
for value in adict.values():
    print(value)
    
    
    
    
    
    
alist = [10,20,30]
if 50 in alist:
    print("exists")
else:
    print("doesnt exist")
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    