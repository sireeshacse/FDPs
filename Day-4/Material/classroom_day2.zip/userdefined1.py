

# fixed arguments
def add(a,b):
    c = a+ b
    return c


tot = add(10,20)
print(tot)