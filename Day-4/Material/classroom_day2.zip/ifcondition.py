


a,b = 10,20

if a < b :
    print(a)
    print("Inside if only")
else:
    print(b)
    print("Inside else only")
    


name = input("Enter any color :")
if name == "red":
    print("red")
elif name == "green":
    print("green")
elif name == "blue":
    print("blue")
else:
    print("Someother color")