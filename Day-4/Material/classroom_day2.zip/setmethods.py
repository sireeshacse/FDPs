


aset = {10,20,30,10,10,10,20,40,50,50,50,50}
bset = {60,70,80,90,100,10}
print(bset)
print(aset)

print(aset.union(bset))
print(aset.difference(bset))

print(aset.intersection(bset))