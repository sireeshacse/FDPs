

# default arguments
def add(a= 0,b = 0 ,c = 0,d =0):
    print(a,b,c,d)


add()
add(10)
add(10,20)
add(10,20,30)
add(10,20,30,40)


# range(start = 0,stop,step= 1)
print(list(range(10)))
print(list(range(1,10)))
print(list(range(1,10,2)))   ( range(start,stop,step))

print(10,20,sep="    ")


print(list(range(10,-10,-1)))






