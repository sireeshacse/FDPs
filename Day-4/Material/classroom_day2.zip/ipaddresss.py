
# objects should be same t

fixed = "192.168.0."

for val in range(1,11):
    ip = fixed + val
    print(ip)