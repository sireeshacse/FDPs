colors = [
   {
     "colors": "red",
     "values": "#f00"
   },
   {
     "colors": "green",
     "values": "#0f0"
   },
   {
     "colors": "black",
     "values": "#000"
    }
]

for item in colors:
    print(item['colors'],item['values'])

   