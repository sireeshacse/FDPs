## importing everything
import math
print(math.log(2))
print(math.tan(1))


# importing specific methods ONLY
from math import sin,cos,floor
print(sin(2))
print(cos(3))


# creating alias name
import math as m
import matplotlib as plt